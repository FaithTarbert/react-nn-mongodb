//npm init
//npm i express cors mongoose nodemon
var express = require('express');
const app = express();
const mongoose = require('mongoose');
require('dotenv').config();
const router = express.Router();
const cors = require('cors');

//hide mongoose connection using .env file (add to .gitignore)
mongoose.connect(process.env.DB_URI,  {
    dbName: process.env.DB_NAME,
    user: process.env.DB_USER,
    pass: process.env.DB_PASS,
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
    .then((res) => console.log('db connected!'))
    .catch((err) => console.log(err));

//cors is for cross platform communication
app.use(cors());
app.use(express.json());
app.use('/', require('./routes/save-to-mdb'));
app.listen(3001, function() {
    console.log('db connected to port 3001');
});


