const express = require('express');
const router = express.Router();
const Post = require('../models/post');


router.route('/create').post((req, res) => {
    const title = req.body.title;
    const body = req.body.body;
    const author = req.body.author;
    const newPost = new Post({
        title,
        body,
        author
    });
    newPost.save();
});
router.route('/').get((req, res) => {
    Post.find()
    .then(foundPosts => res.json(foundPosts));
});
module.exports = router;