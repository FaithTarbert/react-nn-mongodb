//create the mongoose schema model for use by the rest of our application (step 1)
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const postSchema = new Schema({
    // _id: mongoose auto adds an id when item is successfully added to mdb
    title: String,
    body: String,
    author: String,
});

const Post = mongoose.model('Post', postSchema);

module.exports = Post;